# WordPress MySQL database migration
#
# Generated: Tuesday 26. November 2019 06:46 UTC
# Hostname: localhost:3309
# Database: `db_qot`
# URL: //localhost/student
# Path: /Applications/MAMP/htdocs/student
# Tables: qod_commentmeta, qod_comments, qod_links, qod_options, qod_pmxi_files, qod_pmxi_history, qod_pmxi_images, qod_pmxi_imports, qod_pmxi_posts, qod_pmxi_templates, qod_postmeta, qod_posts, qod_term_relationships, qod_term_taxonomy, qod_termmeta, qod_terms, qod_usermeta, qod_users
# Table Prefix: qod_
# Post Types: revision, acf-field, acf-field-group, attachment, nav_menu_item, page, post
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `qod_commentmeta`
#

DROP TABLE IF EXISTS `qod_commentmeta`;


#
# Table structure of table `qod_commentmeta`
#

CREATE TABLE `qod_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `qod_commentmeta`
#

#
# End of data contents of table `qod_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `qod_comments`
#

DROP TABLE IF EXISTS `qod_comments`;


#
# Table structure of table `qod_comments`
#

CREATE TABLE `qod_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `qod_comments`
#

#
# End of data contents of table `qod_comments`
# --------------------------------------------------------



#
# Delete any existing table `qod_links`
#

DROP TABLE IF EXISTS `qod_links`;


#
# Table structure of table `qod_links`
#

CREATE TABLE `qod_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `qod_links`
#

#
# End of data contents of table `qod_links`
# --------------------------------------------------------



#
# Delete any existing table `qod_options`
#

DROP TABLE IF EXISTS `qod_options`;


#
# Table structure of table `qod_options`
#

CREATE TABLE `qod_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=431 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `qod_options`
#
INSERT INTO `qod_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/student', 'yes'),
(2, 'home', 'http://localhost/student', 'yes'),
(3, 'blogname', 'Quotes on Dev', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'soservin@ymail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '101', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '99', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:87:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:40:"index.php?&page_id=244&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:8:{i:0;s:31:"query-monitor/query-monitor.php";i:1;s:30:"advanced-custom-fields/acf.php";i:2;s:47:"show-current-template/show-current-template.php";i:3;s:27:"svg-support/svg-support.php";i:4;s:41:"wordpress-importer/wordpress-importer.php";i:5;s:24:"wp-all-import/plugin.php";i:6;s:31:"wp-migrate-db/wp-migrate-db.php";i:7;s:21:"wp-sweep/wp-sweep.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'qod-starter', 'yes'),
(41, 'stylesheet', 'qod-starter', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '45805', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', 'America/Toronto', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '244', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '1', 'yes'),
(93, 'admin_email_lifespan', '1589743453', 'yes'),
(94, 'initial_db_version', '45805', 'yes'),
(95, 'qod_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(96, 'fresh_site', '0', 'yes'),
(97, 'WPLANG', 'en_CA', 'yes'),
(98, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `qod_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'sidebars_widgets', 'a:2:{s:19:"wp_inactive_widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes'),
(104, 'cron', 'a:6:{i:1574753055;a:4:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1574794660;a:1:{s:21:"ai1wm_storage_cleanup";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1574796254;a:1:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1574796268;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1574797621;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(105, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'recovery_keys', 'a:1:{s:22:"bYF1WeBRCn4sfX3qNCLlV6";a:2:{s:10:"hashed_key";s:34:"$P$B6M4fDAS8upz9ZgC0mxQuD3dljb5c9.";s:10:"created_at";i:1574719299;}}', 'yes'),
(117, 'theme_mods_twentytwenty', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1574192542;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";}s:9:"sidebar-2";a:3:{i:0;s:10:"archives-2";i:1;s:12:"categories-2";i:2;s:6:"meta-2";}}}}', 'yes'),
(131, 'can_compress_scripts', '0', 'no'),
(146, 'recently_activated', 'a:2:{s:27:"theme-check/theme-check.php";i:1574192624;s:36:"contact-form-7/wp-contact-form-7.php";i:1574192618;}', 'yes'),
(149, 'acf_version', '5.8.7', 'yes'),
(170, 'current_theme', 'Quotes on Dev Starter Theme', 'yes'),
(171, 'theme_mods_qod-starter', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:7:"primary";i:41;}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(172, 'theme_switched', '', 'yes'),
(173, 'category_children', 'a:0:{}', 'yes'),
(179, 'PMXI_Plugin_Options', 'a:27:{s:18:"history_file_count";i:10000;s:16:"history_file_age";i:365;s:15:"highlight_limit";i:10000;s:19:"upload_max_filesize";i:2048;s:13:"post_max_size";i:2048;s:14:"max_input_time";i:-1;s:18:"max_execution_time";i:-1;s:7:"dismiss";i:0;s:16:"dismiss_speed_up";i:0;s:18:"dismiss_manage_top";i:0;s:21:"dismiss_manage_bottom";i:0;s:13:"html_entities";i:0;s:11:"utf8_decode";i:0;s:12:"cron_job_key";s:9:"ehp.MEiWc";s:10:"chunk_size";i:32;s:9:"pingbacks";i:1;s:33:"legacy_special_character_handling";i:1;s:14:"case_sensitive";i:1;s:12:"session_mode";s:7:"default";s:17:"enable_ftp_import";i:0;s:16:"large_feed_limit";i:1000;s:26:"cron_processing_time_limit";i:120;s:6:"secure";i:1;s:11:"log_storage";i:5;s:10:"cron_sleep";s:0:"";s:4:"port";s:0:"";s:19:"force_stream_reader";i:0;}', 'yes'),
(180, 'pmxi_is_migrated', '3.5.2', 'yes'),
(242, 'bodhi_svgs_plugin_version', '2.3.15', 'yes'),
(246, 'recovery_mode_email_last_sent', '1574719299', 'yes'),
(272, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1574750788;}', 'no'),
(286, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(347, 'ai1wm_secret_key', 'iruCYQLNFUk4', 'yes'),
(355, 'ai1wm_updater', 'a:0:{}', 'yes'),
(381, 'ai1wm_status', 'a:2:{s:4:"type";s:8:"download";s:7:"message";s:292:"<a href="http://localhost/student/wp-content/ai1wm-backups/localhost-qod-20191124-003339-968.wpress" class="ai1wm-button-green ai1wm-emphasize ai1wm-button-download" title="localhost" download="localhost-qod-20191124-003339-968.wpress"><span>Download localhost</span><em>Size: 223 MB</em></a>";}', 'yes') ;

#
# End of data contents of table `qod_options`
# --------------------------------------------------------



#
# Delete any existing table `qod_pmxi_files`
#

DROP TABLE IF EXISTS `qod_pmxi_files`;


#
# Table structure of table `qod_pmxi_files`
#

CREATE TABLE `qod_pmxi_files` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `import_id` bigint(20) unsigned NOT NULL,
  `name` text COLLATE utf8mb4_unicode_520_ci,
  `path` text COLLATE utf8mb4_unicode_520_ci,
  `registered_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `qod_pmxi_files`
#

#
# End of data contents of table `qod_pmxi_files`
# --------------------------------------------------------



#
# Delete any existing table `qod_pmxi_history`
#

DROP TABLE IF EXISTS `qod_pmxi_history`;


#
# Table structure of table `qod_pmxi_history`
#

CREATE TABLE `qod_pmxi_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `import_id` bigint(20) unsigned NOT NULL,
  `type` enum('manual','processing','trigger','continue','') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `time_run` text COLLATE utf8mb4_unicode_520_ci,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `summary` text COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `qod_pmxi_history`
#

#
# End of data contents of table `qod_pmxi_history`
# --------------------------------------------------------



#
# Delete any existing table `qod_pmxi_images`
#

DROP TABLE IF EXISTS `qod_pmxi_images`;


#
# Table structure of table `qod_pmxi_images`
#

CREATE TABLE `qod_pmxi_images` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attachment_id` bigint(20) unsigned NOT NULL,
  `image_url` varchar(600) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `image_filename` varchar(600) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `qod_pmxi_images`
#
INSERT INTO `qod_pmxi_images` ( `id`, `attachment_id`, `image_url`, `image_filename`) VALUES
(1, 225, '', 'qod-logo.svg'),
(2, 235, '', '1f642.svg') ;

#
# End of data contents of table `qod_pmxi_images`
# --------------------------------------------------------



#
# Delete any existing table `qod_pmxi_imports`
#

DROP TABLE IF EXISTS `qod_pmxi_imports`;


#
# Table structure of table `qod_pmxi_imports`
#

CREATE TABLE `qod_pmxi_imports` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parent_import_id` bigint(20) NOT NULL DEFAULT '0',
  `name` text COLLATE utf8mb4_unicode_520_ci,
  `friendly_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `type` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `feed_type` enum('xml','csv','zip','gz','') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `path` text COLLATE utf8mb4_unicode_520_ci,
  `xpath` text COLLATE utf8mb4_unicode_520_ci,
  `options` longtext COLLATE utf8mb4_unicode_520_ci,
  `registered_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `root_element` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `processing` tinyint(1) NOT NULL DEFAULT '0',
  `executing` tinyint(1) NOT NULL DEFAULT '0',
  `triggered` tinyint(1) NOT NULL DEFAULT '0',
  `queue_chunk_number` bigint(20) NOT NULL DEFAULT '0',
  `first_import` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `count` bigint(20) NOT NULL DEFAULT '0',
  `imported` bigint(20) NOT NULL DEFAULT '0',
  `created` bigint(20) NOT NULL DEFAULT '0',
  `updated` bigint(20) NOT NULL DEFAULT '0',
  `skipped` bigint(20) NOT NULL DEFAULT '0',
  `deleted` bigint(20) NOT NULL DEFAULT '0',
  `canceled` tinyint(1) NOT NULL DEFAULT '0',
  `canceled_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `failed` tinyint(1) NOT NULL DEFAULT '0',
  `failed_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `settings_update_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_activity` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `iteration` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `qod_pmxi_imports`
#

#
# End of data contents of table `qod_pmxi_imports`
# --------------------------------------------------------



#
# Delete any existing table `qod_pmxi_posts`
#

DROP TABLE IF EXISTS `qod_pmxi_posts`;


#
# Table structure of table `qod_pmxi_posts`
#

CREATE TABLE `qod_pmxi_posts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL,
  `import_id` bigint(20) unsigned NOT NULL,
  `unique_key` text COLLATE utf8mb4_unicode_520_ci,
  `product_key` text COLLATE utf8mb4_unicode_520_ci,
  `iteration` bigint(20) NOT NULL DEFAULT '0',
  `specified` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `qod_pmxi_posts`
#

#
# End of data contents of table `qod_pmxi_posts`
# --------------------------------------------------------



#
# Delete any existing table `qod_pmxi_templates`
#

DROP TABLE IF EXISTS `qod_pmxi_templates`;


#
# Table structure of table `qod_pmxi_templates`
#

CREATE TABLE `qod_pmxi_templates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `options` longtext COLLATE utf8mb4_unicode_520_ci,
  `scheduled` varchar(64) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `title` text COLLATE utf8mb4_unicode_520_ci,
  `content` longtext COLLATE utf8mb4_unicode_520_ci,
  `is_keep_linebreaks` tinyint(1) NOT NULL DEFAULT '0',
  `is_leave_html` tinyint(1) NOT NULL DEFAULT '0',
  `fix_characters` tinyint(1) NOT NULL DEFAULT '0',
  `meta` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `qod_pmxi_templates`
#

#
# End of data contents of table `qod_pmxi_templates`
# --------------------------------------------------------



#
# Delete any existing table `qod_postmeta`
#

DROP TABLE IF EXISTS `qod_postmeta`;


#
# Table structure of table `qod_postmeta`
#

CREATE TABLE `qod_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=355 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `qod_postmeta`
#
INSERT INTO `qod_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(13, 19, '_edit_last', '1'),
(14, 21, '_edit_last', '1'),
(15, 21, '_qod_quote_source', 'The Structure and Interpretation of Computer Programs'),
(16, 23, '_edit_last', '1'),
(17, 25, '_edit_last', '1'),
(18, 27, '_edit_last', '1'),
(19, 29, '_edit_last', '1'),
(20, 31, '_edit_last', '1'),
(21, 33, '_edit_last', '1'),
(22, 33, '_qod_quote_source', 'Program or Be Programmed: Ten Commands for a Digital Age'),
(23, 35, '_edit_last', '1'),
(24, 37, '_edit_last', '1'),
(25, 37, '_qod_quote_source', 'Code Simplicity: The Fundamentals of Software'),
(26, 39, '_edit_last', '1'),
(27, 41, '_edit_last', '1'),
(28, 43, '_edit_last', '1'),
(29, 45, '_edit_last', '1'),
(30, 47, '_edit_last', '1'),
(31, 49, '_edit_last', '1'),
(32, 51, '_edit_last', '1'),
(33, 51, '_qod_quote_source', 'Game Programming Patterns'),
(34, 53, '_edit_last', '1'),
(35, 53, '_qod_quote_source', 'Game Programming Patterns'),
(36, 55, '_edit_last', '1'),
(37, 55, '_qod_quote_source', 'Clean Code: A Handbook of Agile Software Craftsmanship'),
(38, 57, '_edit_last', '1'),
(39, 57, '_qod_quote_source', 'Working Effectively with Legacy Code'),
(40, 59, '_edit_last', '1'),
(41, 61, '_edit_last', '1'),
(43, 63, '_edit_last', '1'),
(44, 65, '_edit_last', '1'),
(45, 67, '_edit_last', '1'),
(46, 69, '_edit_last', '1'),
(47, 71, '_edit_last', '1'),
(48, 73, '_edit_last', '1'),
(49, 75, '_edit_last', '1'),
(50, 77, '_edit_last', '1'),
(51, 79, '_edit_last', '1'),
(52, 79, '_qod_quote_source', 'The Mythical Man-Month'),
(53, 81, '_edit_last', '1'),
(54, 83, '_edit_last', '1'),
(55, 85, '_edit_last', '1'),
(56, 87, '_edit_last', '1'),
(57, 89, '_edit_last', '1'),
(58, 89, '_qod_quote_source', 'christianheilmann.com'),
(59, 89, '_qod_quote_source_url', 'https://www.christianheilmann.com/2005/11/08/do-hr-people-even-read-their-job-ads-when-they-get-published/'),
(60, 91, '_edit_last', '1'),
(61, 91, '_qod_quote_source', 'What Is Code?'),
(62, 91, '_qod_quote_source_url', 'http://www.bloomberg.com/graphics/2015-paul-ford-what-is-code/'),
(63, 93, '_edit_last', '1'),
(64, 95, '_edit_last', '1'),
(65, 97, '_edit_last', '1'),
(66, 101, '_edit_last', '1'),
(67, 101, '_qod_quote_source', 'The Art of Web Design'),
(68, 101, '_qod_quote_source_url', 'https://www.google.ca/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0CDkQtwIwAGoVChMI1uS97rLuyAIVVfFjCh3DFwrM&url=http%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3D3iVVM_DgWY4&usg=AFQjCNGKP6BAccnj6iPxgUB_UhEsW-A5xg'),
(69, 103, '_edit_last', '1'),
(70, 103, '_qod_quote_source', 'gerrymcgovern.com'),
(71, 103, '_qod_quote_source_url', 'http://www.gerrymcgovern.com/new-thinking/why-do-organizations-hate-their-content-management-system'),
(72, 105, '_edit_last', '1'),
(73, 105, '_qod_quote_source', 'Medium'),
(74, 105, '_qod_quote_source_url', 'https://medium.com/javascript-scene/the-two-pillars-of-javascript-ee6f3281e7f3'),
(75, 159, '_edit_last', '1'),
(76, 161, '_edit_last', '1'),
(77, 161, '_qod_quote_source', '@sanityinc'),
(78, 161, '_qod_quote_source_url', 'https://twitter.com/sanityinc'),
(79, 163, '_edit_last', '1'),
(80, 163, '_qod_quote_source', '@iamdevloper'),
(81, 163, '_qod_quote_source_url', 'https://twitter.com/iamdevloper'),
(82, 165, '_edit_last', '1'),
(83, 165, '_qod_quote_source', '@garybernhardt'),
(84, 165, '_qod_quote_source_url', 'https://twitter.com/garybernhardt'),
(85, 169, '_edit_last', '1'),
(86, 169, '_qod_quote_source', '@tomscott'),
(87, 169, '_qod_quote_source_url', 'https://twitter.com/tomscott'),
(88, 171, '_edit_last', '1'),
(89, 171, '_qod_quote_source', '@d6'),
(90, 171, '_qod_quote_source_url', 'https://twitter.com/d6'),
(91, 173, '_edit_last', '1'),
(92, 173, '_qod_quote_source', '@JaesCoyle'),
(93, 173, '_qod_quote_source_url', 'https://twitter.com/JaesCoyle'),
(94, 175, '_edit_last', '1'),
(95, 175, '_qod_quote_source', '@nedbat'),
(96, 175, '_qod_quote_source_url', 'https://twitter.com/nedbat'),
(97, 177, '_edit_last', '1'),
(98, 177, '_qod_quote_source', '@fortes'),
(99, 177, '_qod_quote_source_url', 'https://twitter.com/fortes'),
(100, 179, '_edit_last', '1'),
(101, 179, '_qod_quote_source', '@mhoye'),
(102, 179, '_qod_quote_source_url', 'https://twitter.com/mhoye'),
(103, 181, '_edit_last', '1'),
(104, 204, '_edit_last', '1'),
(105, 204, '_qod_quote_source', '@jamesshore'),
(106, 204, '_qod_quote_source_url', 'https://twitter.com/jamesshore'),
(206, 207, '_edit_lock', '1574370855:1'),
(208, 211, '_edit_lock', '1574370712:1'),
(210, 215, '_edit_lock', '1574379899:1'),
(211, 217, '_edit_lock', '1574370461:1'),
(219, 105, '_edit_lock', '1574284409:1'),
(220, 204, '_edit_lock', '1574468319:1'),
(231, 225, '_wp_attached_file', '2019/11/qod-logo.svg') ;
INSERT INTO `qod_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(232, 226, '_edit_last', '1'),
(233, 226, '_edit_lock', '1574466704:1'),
(234, 77, '_edit_lock', '1574295204:1'),
(235, 33, '_edit_lock', '1574295211:1'),
(236, 225, '_wp_attachment_image_alt', 'qod-logo'),
(237, 228, '_menu_item_type', 'custom'),
(238, 228, '_menu_item_menu_item_parent', '0'),
(239, 228, '_menu_item_object_id', '228'),
(240, 228, '_menu_item_object', 'custom'),
(241, 228, '_menu_item_target', ''),
(242, 228, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(243, 228, '_menu_item_xfn', ''),
(244, 228, '_menu_item_url', 'http://localhost/student/'),
(245, 228, '_menu_item_orphaned', '1574369022'),
(246, 229, '_menu_item_type', 'post_type'),
(247, 229, '_menu_item_menu_item_parent', '0'),
(248, 229, '_menu_item_object_id', '215'),
(249, 229, '_menu_item_object', 'page'),
(250, 229, '_menu_item_target', ''),
(251, 229, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(252, 229, '_menu_item_xfn', ''),
(253, 229, '_menu_item_url', ''),
(255, 230, '_menu_item_type', 'post_type'),
(256, 230, '_menu_item_menu_item_parent', '0'),
(257, 230, '_menu_item_object_id', '211'),
(258, 230, '_menu_item_object', 'page'),
(259, 230, '_menu_item_target', ''),
(260, 230, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(261, 230, '_menu_item_xfn', ''),
(262, 230, '_menu_item_url', ''),
(264, 231, '_menu_item_type', 'post_type'),
(265, 231, '_menu_item_menu_item_parent', '0'),
(266, 231, '_menu_item_object_id', '217'),
(267, 231, '_menu_item_object', 'page'),
(268, 231, '_menu_item_target', ''),
(269, 231, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(270, 231, '_menu_item_xfn', ''),
(271, 231, '_menu_item_url', ''),
(272, 231, '_menu_item_orphaned', '1574369022'),
(273, 232, '_menu_item_type', 'post_type'),
(274, 232, '_menu_item_menu_item_parent', '0'),
(275, 232, '_menu_item_object_id', '207'),
(276, 232, '_menu_item_object', 'page'),
(277, 232, '_menu_item_target', ''),
(278, 232, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(279, 232, '_menu_item_xfn', ''),
(280, 232, '_menu_item_url', ''),
(282, 233, '_menu_item_type', 'custom'),
(283, 233, '_menu_item_menu_item_parent', '0'),
(284, 233, '_menu_item_object_id', '233'),
(285, 233, '_menu_item_object', 'custom'),
(286, 233, '_menu_item_target', ''),
(287, 233, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(288, 233, '_menu_item_xfn', ''),
(289, 233, '_menu_item_url', 'https://redacademy.com/'),
(291, 235, '_wp_attached_file', '2019/11/1f642.svg'),
(292, 235, '_wp_attachment_image_alt', 'smile-svg'),
(293, 215, 'inline_featured_image', '0'),
(294, 215, '_edit_last', '1'),
(295, 215, 'qod_logo', '225'),
(296, 215, '_qod_logo', 'field_5dd5b1f1a1a60'),
(297, 236, 'qod_logo', ''),
(298, 236, '_qod_logo', 'field_5dd5b1f1a1a60'),
(299, 237, 'qod_logo', '225'),
(300, 237, '_qod_logo', 'field_5dd5b1f1a1a60'),
(301, 211, 'inline_featured_image', '0'),
(302, 211, '_edit_last', '1'),
(303, 211, 'qod_logo', '225'),
(304, 211, '_qod_logo', 'field_5dd5b1f1a1a60'),
(305, 239, 'qod_logo', '225'),
(306, 239, '_qod_logo', 'field_5dd5b1f1a1a60'),
(307, 207, 'inline_featured_image', '0'),
(308, 207, '_edit_last', '1'),
(309, 207, 'qod_logo', '225'),
(310, 207, '_qod_logo', 'field_5dd5b1f1a1a60'),
(311, 241, 'qod_logo', '225'),
(312, 241, '_qod_logo', 'field_5dd5b1f1a1a60'),
(313, 217, '_wp_trash_meta_status', 'publish'),
(314, 217, '_wp_trash_meta_time', '1574372873'),
(315, 217, '_wp_desired_post_slug', 'home'),
(316, 217, 'inline_featured_image', '0'),
(317, 244, 'inline_featured_image', '0'),
(318, 244, '_edit_lock', '1574375061:1'),
(319, 244, '_edit_last', '1'),
(320, 244, 'qod_logo', '225'),
(321, 244, '_qod_logo', 'field_5dd5b1f1a1a60'),
(322, 246, 'qod_logo', '225'),
(323, 246, '_qod_logo', 'field_5dd5b1f1a1a60'),
(324, 247, 'inline_featured_image', '0'),
(329, 204, 'inline_featured_image', '0'),
(331, 204, 'qod_logo', '225'),
(332, 204, '_qod_logo', 'field_5dd5b1f1a1a60'),
(333, 250, 'qod_logo', '225'),
(334, 250, '_qod_logo', 'field_5dd5b1f1a1a60'),
(335, 251, 'inline_featured_image', '0'),
(338, 251, '_qod_quote_source', 'test-source'),
(339, 251, '_qod_quote_source_url', 'test-source-url.com'),
(340, 251, '_wp_trash_meta_status', 'publish'),
(341, 251, '_wp_trash_meta_time', '1574717072'),
(342, 251, '_wp_desired_post_slug', 'test-title') ;
INSERT INTO `qod_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(343, 253, 'inline_featured_image', '0'),
(344, 254, 'inline_featured_image', '0'),
(345, 254, '_wp_trash_meta_status', 'draft'),
(346, 254, '_wp_trash_meta_time', '1574720839'),
(347, 254, '_wp_desired_post_slug', ''),
(348, 253, '_wp_trash_meta_status', 'draft'),
(349, 253, '_wp_trash_meta_time', '1574720843'),
(350, 253, '_wp_desired_post_slug', ''),
(351, 257, 'inline_featured_image', '0'),
(352, 257, '_wp_trash_meta_status', 'draft'),
(353, 257, '_wp_trash_meta_time', '1574720987'),
(354, 257, '_wp_desired_post_slug', '') ;

#
# End of data contents of table `qod_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `qod_posts`
#

DROP TABLE IF EXISTS `qod_posts`;


#
# Table structure of table `qod_posts`
#

CREATE TABLE `qod_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=260 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `qod_posts`
#
INSERT INTO `qod_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(19, 1, '2015-10-30 23:13:59', '2015-10-30 23:13:59', '<!-- wp:paragraph -->\n<p>Talk is cheap. Show me the code.</p>\n<!-- /wp:paragraph -->', 'Linus Torvalds', '', 'publish', 'open', 'open', '', 'linus-torvalds', '', '', '2015-10-30 23:13:59', '2015-10-30 23:13:59', '', 0, 'http://localhost/quotesondev/?p=19', 0, 'post', '', 0),
(21, 1, '2015-10-30 23:35:43', '2015-10-30 23:35:43', '<!-- wp:paragraph -->\n<p>Programs must be written for people to read, and only incidentally for machines to execute.</p>\n<!-- /wp:paragraph -->', 'Harold Abelson', '', 'publish', 'open', 'open', '', 'harold-abelson', '', '', '2015-10-30 23:35:43', '2015-10-30 23:35:43', '', 0, 'http://localhost/quotesondev/?p=21', 0, 'post', '', 0),
(23, 1, '2015-10-30 23:36:35', '2015-10-30 23:36:35', '<!-- wp:paragraph -->\n<p>Always code as if the guy who ends up maintaining your code will be a violent psychopath who knows where you live.</p>\n<!-- /wp:paragraph -->', 'John Woods', '', 'publish', 'open', 'open', '', 'john-woods', '', '', '2015-10-30 23:36:35', '2015-10-30 23:36:35', '', 0, 'http://localhost/quotesondev/?p=23', 0, 'post', '', 0),
(25, 1, '2015-10-30 23:40:03', '2015-10-30 23:40:03', '<!-- wp:paragraph -->\n<p>Give a man a program, frustrate him for a day. Teach a man to program, frustrate him for a lifetime.</p>\n<!-- /wp:paragraph -->', 'Waseem Latif', '', 'publish', 'open', 'open', '', 'waseem-latif', '', '', '2015-10-30 23:40:03', '2015-10-30 23:40:03', '', 0, 'http://localhost/quotesondev/?p=25', 0, 'post', '', 0),
(27, 1, '2015-10-31 20:25:18', '2015-10-31 20:25:18', '<!-- wp:paragraph -->\n<p>Perl – The only language that looks the same before and after RSA encryption.</p>\n<!-- /wp:paragraph -->', 'Keith Bostic', '', 'publish', 'open', 'open', '', 'keith-bostic', '', '', '2015-10-31 20:25:18', '2015-10-31 20:25:18', '', 0, 'http://localhost/quotesondev/?p=27', 0, 'post', '', 0),
(29, 1, '2015-10-31 20:26:50', '2015-10-31 20:26:50', '<!-- wp:paragraph -->\n<p>Walking on water and developing software from a specification are easy if both are frozen.</p>\n<!-- /wp:paragraph -->', 'Edward Berard', '', 'publish', 'open', 'open', '', 'edward-berard', '', '', '2015-10-31 20:26:50', '2015-10-31 20:26:50', '', 0, 'http://localhost/quotesondev/?p=29', 0, 'post', '', 0),
(31, 1, '2015-10-31 20:27:03', '2015-10-31 20:27:03', '<!-- wp:paragraph -->\n<p>The most important property of a program is whether it accomplishes the intention of its user.</p>\n<!-- /wp:paragraph -->', 'C.A.R. Hoare', '', 'publish', 'open', 'open', '', 'c-a-r-hoare', '', '', '2015-10-31 20:27:03', '2015-10-31 20:27:03', '', 0, 'http://localhost/quotesondev/?p=31', 0, 'post', '', 0),
(33, 1, '2015-10-31 20:27:54', '2015-10-31 20:27:54', '<!-- wp:paragraph -->\n<p>We are looking at a society increasingly dependent on machines, yet decreasingly capable of making or even using them effectively.</p>\n<!-- /wp:paragraph -->', 'Douglas Rushkoff', '', 'publish', 'open', 'open', '', 'douglas-rushkoff', '', '', '2015-10-31 20:27:54', '2015-10-31 20:27:54', '', 0, 'http://localhost/quotesondev/?p=33', 0, 'post', '', 0),
(35, 1, '2015-10-31 20:28:34', '2015-10-31 20:28:34', '<!-- wp:paragraph -->\n<p>I\'m not a great programmer; I\'m just a good programmer with great habits.</p>\n<!-- /wp:paragraph -->', 'Kent Beck', '', 'publish', 'open', 'open', '', 'kent-beck', '', '', '2015-10-31 20:28:34', '2015-10-31 20:28:34', '', 0, 'http://localhost/quotesondev/?p=35', 0, 'post', '', 0),
(37, 1, '2015-10-31 20:29:52', '2015-10-31 20:29:52', '<!-- wp:paragraph -->\n<p>Some of the best programming is done on paper, really. Putting it into the computer is just a minor detail.</p>\n<!-- /wp:paragraph -->', 'Max Kanat-Alexander', '', 'publish', 'open', 'open', '', 'max-kanat-alexander', '', '', '2015-10-31 20:29:52', '2015-10-31 20:29:52', '', 0, 'http://localhost/quotesondev/?p=37', 0, 'post', '', 0),
(39, 1, '2015-10-31 20:30:38', '2015-10-31 20:30:38', '<!-- wp:paragraph -->\n<p>Any fool can write code that a computer can understand. Good programmers write code that humans can understand.</p>\n<!-- /wp:paragraph -->', 'Martin Fowler', '', 'publish', 'open', 'open', '', 'martin-fowler', '', '', '2015-10-31 20:30:38', '2015-10-31 20:30:38', '', 0, 'http://localhost/quotesondev/?p=39', 0, 'post', '', 0),
(41, 1, '2015-10-31 20:32:56', '2015-10-31 20:32:56', '<!-- wp:paragraph -->\n<p>Simplicity is prerequisite for reliability.</p>\n<!-- /wp:paragraph -->', 'Edsger W. Dijkstra', '', 'publish', 'open', 'open', '', 'edsger-w-dijkstra', '', '', '2015-10-31 20:32:56', '2015-10-31 20:32:56', '', 0, 'http://localhost/quotesondev/?p=41', 0, 'post', '', 0),
(43, 1, '2015-10-31 20:33:49', '2015-10-31 20:33:49', '<!-- wp:paragraph -->\n<p>The Analytical Engine weaves algebraic patterns, just as the Jacquard loom weaves flowers and leaves.</p>\n<!-- /wp:paragraph -->', 'Ada Lovelace', '', 'publish', 'open', 'open', '', 'ada-lovelace', '', '', '2015-10-31 20:33:49', '2015-10-31 20:33:49', '', 0, 'http://localhost/quotesondev/?p=43', 0, 'post', '', 0),
(45, 1, '2015-10-31 20:34:48', '2015-10-31 20:34:48', '<!-- wp:paragraph -->\n<p>Sometimes it pays to stay in bed on Monday, rather than spending the rest of the week debugging Monday\'s code</p>\n<!-- /wp:paragraph -->', 'Dan Salomon', '', 'publish', 'open', 'open', '', 'dan-salomon', '', '', '2015-10-31 20:34:48', '2015-10-31 20:34:48', '', 0, 'http://localhost/quotesondev/?p=45', 0, 'post', '', 0),
(47, 1, '2015-10-31 20:35:52', '2015-10-31 20:35:52', '<!-- wp:paragraph -->\n<p>It goes against the grain of modern education to teach children to program. What fun is there in making plans, acquiring discipline in organizing thoughts, devoting attention to detail and learning to be self-critical?</p>\n<!-- /wp:paragraph -->', 'Alan J. Perlis', '', 'publish', 'open', 'open', '', 'alan-j-perlis', '', '', '2015-10-31 20:35:52', '2015-10-31 20:35:52', '', 0, 'http://localhost/quotesondev/?p=47', 0, 'post', '', 0),
(49, 1, '2015-10-31 20:36:12', '2015-10-31 20:36:12', '<!-- wp:paragraph -->\n<p>Kids who are good at traditional school—repeating rote concepts and facts on a test—can fall apart in a situation where that isn’t enough. Programming rewards the experimental, curious mind.</p>\n<!-- /wp:paragraph -->', 'Ketil Moland Olsen', '', 'publish', 'open', 'open', '', 'ketil-moland-olsen', '', '', '2015-10-31 20:36:12', '2015-10-31 20:36:12', '', 0, 'http://localhost/quotesondev/?p=49', 0, 'post', '', 0),
(51, 1, '2015-10-31 20:37:22', '2015-10-31 20:37:22', '<!-- wp:paragraph -->\n<p>Like so many things in software, MVC was invented by Smalltalkers in the seventies. Lispers probably claim they came up with it in the sixties but didn\'t bother writing it down.</p>\n<!-- /wp:paragraph -->', 'Robert Nystrom', '', 'publish', 'open', 'open', '', 'robert-nystrom', '', '', '2015-10-31 20:37:22', '2015-10-31 20:37:22', '', 0, 'http://localhost/quotesondev/?p=51', 0, 'post', '', 0),
(53, 1, '2015-10-31 20:38:02', '2015-10-31 20:38:02', '<!-- wp:paragraph -->\n<p>Most non-programmers don\'t think of plaintext like that. To them, text files feel like filling in tax forms for an angry robotic auditor that yells at them if they forget a single semicolon.</p>\n<!-- /wp:paragraph -->', 'Robert Nystrom', '', 'publish', 'open', 'open', '', 'robert-nystrom-2', '', '', '2015-10-31 20:38:02', '2015-10-31 20:38:02', '', 0, 'http://localhost/quotesondev/?p=53', 0, 'post', '', 0),
(55, 1, '2015-10-31 20:39:09', '2015-10-31 20:39:09', '<!-- wp:paragraph -->\n<p>Truth can only be found in one place: the code.</p>\n<!-- /wp:paragraph -->', 'Robert C. Martin', '', 'publish', 'open', 'open', '', 'robert-c-martin', '', '', '2015-10-31 20:39:09', '2015-10-31 20:39:09', '', 0, 'http://localhost/quotesondev/?p=55', 0, 'post', '', 0),
(57, 1, '2015-10-31 20:39:46', '2015-10-31 20:39:46', '<!-- wp:paragraph -->\n<p>Programming is the art of doing one thing at a time.</p>\n<!-- /wp:paragraph -->', 'Michael C. Feathers', '', 'publish', 'open', 'open', '', 'michael-c-feathers', '', '', '2015-10-31 20:39:46', '2015-10-31 20:39:46', '', 0, 'http://localhost/quotesondev/?p=57', 0, 'post', '', 0),
(59, 1, '2015-10-31 20:57:19', '2015-10-31 20:57:19', '<!-- wp:paragraph -->\n<p>I love deadlines. I like the whooshing sound they make as they go by.</p>\n<!-- /wp:paragraph -->', 'Douglas Adams', '', 'publish', 'open', 'open', '', 'douglas-adams', '', '', '2015-10-31 20:57:19', '2015-10-31 20:57:19', '', 0, 'http://localhost/quotesondev/?p=59', 0, 'post', '', 0),
(61, 1, '2015-10-31 20:57:57', '2015-10-31 20:57:57', '<!-- wp:paragraph -->\n<p>If debugging is the process of removing software bugs, then programming must be the process of putting them in.</p>\n<!-- /wp:paragraph -->', 'Edsger W. Dijkstra', '', 'publish', 'open', 'open', '', 'edsger-w-dijkstra-2', '', '', '2015-10-31 20:57:57', '2015-10-31 20:57:57', '', 0, 'http://localhost/quotesondev/?p=61', 0, 'post', '', 0),
(63, 1, '2015-10-31 20:58:40', '2015-10-31 20:58:40', '<!-- wp:paragraph -->\n<p>There are two ways of constructing a software design: One way is to make it so simple that there are obviously no deficiencies, and the other way is to make it so complicated that there are no obvious deficiencies. The first method is far more difficult.</p>\n<!-- /wp:paragraph -->', 'C.A.R. Hoare', '', 'publish', 'open', 'open', '', 'c-a-r-hoare-2', '', '', '2015-10-31 20:58:40', '2015-10-31 20:58:40', '', 0, 'http://localhost/quotesondev/?p=63', 0, 'post', '', 0),
(65, 1, '2015-10-31 20:59:24', '2015-10-31 20:59:24', '<!-- wp:paragraph -->\n<p>Measuring programming progress by lines of code is like measuring aircraft building progress by weight.</p>\n<!-- /wp:paragraph -->', 'Bill Gates', '', 'publish', 'open', 'open', '', 'bill-gates', '', '', '2015-10-31 20:59:24', '2015-10-31 20:59:24', '', 0, 'http://localhost/quotesondev/?p=65', 0, 'post', '', 0),
(67, 1, '2015-10-31 21:00:01', '2015-10-31 21:00:01', '<!-- wp:paragraph -->\n<p>Most good programmers do programming not because they expect to get paid or get adulation by the public, but because it is fun to program.</p>\n<!-- /wp:paragraph -->', 'Linus Torvalds', '', 'publish', 'open', 'open', '', 'linus-torvalds-2', '', '', '2015-10-31 21:00:01', '2015-10-31 21:00:01', '', 0, 'http://localhost/quotesondev/?p=67', 0, 'post', '', 0),
(69, 1, '2015-10-31 21:00:54', '2015-10-31 21:00:54', '<!-- wp:paragraph -->\n<p>People think that computer science is the art of geniuses but the actual reality is the opposite, just many people doing things that build on each other, like a wall of mini stones.</p>\n<!-- /wp:paragraph -->', 'Donald Knuth', '', 'publish', 'open', 'open', '', 'donald-knuth', '', '', '2015-10-31 21:00:54', '2015-10-31 21:00:54', '', 0, 'http://localhost/quotesondev/?p=69', 0, 'post', '', 0),
(71, 1, '2015-10-31 21:01:52', '2015-10-31 21:01:52', '<!-- wp:paragraph -->\n<p>One of my most productive days was throwing away 1000 lines of code.</p>\n<!-- /wp:paragraph -->', 'Ken Thompson', '', 'publish', 'open', 'open', '', 'ken-thompson', '', '', '2015-10-31 21:01:52', '2015-10-31 21:01:52', '', 0, 'http://localhost/quotesondev/?p=71', 0, 'post', '', 0),
(73, 1, '2015-10-31 21:02:24', '2015-10-31 21:02:24', '<!-- wp:paragraph -->\n<p>If builders built buildings the way programmers wrote programs, then the first woodpecker that came along wound destroy civilization.</p>\n<!-- /wp:paragraph -->', 'Gerald Weinberg', '', 'publish', 'open', 'open', '', 'gerald-weinberg', '', '', '2015-10-31 21:02:24', '2015-10-31 21:02:24', '', 0, 'http://localhost/quotesondev/?p=73', 0, 'post', '', 0),
(75, 1, '2015-10-31 21:03:04', '2015-10-31 21:03:04', '<!-- wp:paragraph -->\n<p>Debugging is twice as hard as writing the code in the first place. Therefore, if you write the code as cleverly as possible, you are, by definition, not smart enough to debug it.</p>\n<!-- /wp:paragraph -->', 'Brian W. Kernighan', '', 'publish', 'open', 'open', '', 'brian-w-kernighan', '', '', '2015-10-31 21:03:04', '2015-10-31 21:03:04', '', 0, 'http://localhost/quotesondev/?p=75', 0, 'post', '', 0),
(77, 1, '2015-10-31 21:03:48', '2015-10-31 21:03:48', '<!-- wp:paragraph -->\n<p>Some people, when confronted with a problem, think "I know, I\'ll use regular expressions." Now they have two problems.</p>\n<!-- /wp:paragraph -->', 'Jamie Zawinski', '', 'publish', 'open', 'open', '', 'jamie-zawinski', '', '', '2015-10-31 21:03:48', '2015-10-31 21:03:48', '', 0, 'http://localhost/quotesondev/?p=77', 0, 'post', '', 0),
(79, 1, '2015-10-31 21:04:45', '2015-10-31 21:04:45', '<!-- wp:paragraph -->\n<p>Nine people can\'t make a baby in a month.</p>\n<!-- /wp:paragraph -->', 'Fred Brooks', '', 'publish', 'open', 'open', '', 'fred-brooks', '', '', '2015-10-31 21:04:45', '2015-10-31 21:04:45', '', 0, 'http://localhost/quotesondev/?p=79', 0, 'post', '', 0),
(81, 1, '2015-10-31 21:05:37', '2015-10-31 21:05:37', '<!-- wp:paragraph -->\n<p>Computer Science is no more about computers than astronomy is about telescopes.</p>\n<!-- /wp:paragraph -->', 'Edsger W. Dijkstra', '', 'publish', 'open', 'open', '', 'edsger-w-dijkstra-3', '', '', '2015-10-31 21:05:37', '2015-10-31 21:05:37', '', 0, 'http://localhost/quotesondev/?p=81', 0, 'post', '', 0),
(83, 1, '2015-10-31 21:06:01', '2015-10-31 21:06:01', '<!-- wp:paragraph -->\n<p>There are only two kinds of languages: the ones people complain about and the ones nobody uses.</p>\n<!-- /wp:paragraph -->', 'Bjarne Stroustrup', '', 'publish', 'open', 'open', '', 'bjarne-stroustrup', '', '', '2015-10-31 21:06:01', '2015-10-31 21:06:01', '', 0, 'http://localhost/quotesondev/?p=83', 0, 'post', '', 0),
(85, 1, '2015-10-31 21:06:22', '2015-10-31 21:06:22', '<!-- wp:paragraph -->\n<p>The best thing about a boolean is even if you are wrong, you are only off by a bit.</p>\n<!-- /wp:paragraph -->', 'Anonymous', '', 'publish', 'open', 'open', '', 'anonymous', '', '', '2015-10-31 21:06:22', '2015-10-31 21:06:22', '', 0, 'http://localhost/quotesondev/?p=85', 0, 'post', '', 0),
(87, 1, '2015-10-31 21:07:06', '2015-10-31 21:07:06', '<!-- wp:paragraph -->\n<p>Commenting your code is like cleaning your bathroom—you never want to do it, but it really does create a more pleasant experience for you and your guests.</p>\n<!-- /wp:paragraph -->', 'Ryan Campbell', '', 'publish', 'open', 'open', '', 'ryan-campbell', '', '', '2015-10-31 21:07:06', '2015-10-31 21:07:06', '', 0, 'http://localhost/quotesondev/?p=87', 0, 'post', '', 0),
(89, 1, '2015-10-31 21:07:37', '2015-10-31 21:07:37', '<!-- wp:paragraph -->\n<p>Java is to JavaScript as car is to carpet.</p>\n<!-- /wp:paragraph -->', 'Chris Heilmann', '', 'publish', 'open', 'open', '', 'chris-heilmann', '', '', '2015-10-31 21:07:37', '2015-10-31 21:07:37', '', 0, 'http://localhost/quotesondev/?p=89', 0, 'post', '', 0),
(91, 1, '2015-10-31 21:10:27', '2015-10-31 21:10:27', '<!-- wp:paragraph -->\n<p>A computer is a clock with benefits.</p>\n<!-- /wp:paragraph -->', 'Paul Ford', '', 'publish', 'open', 'open', '', 'paul-ford', '', '', '2015-10-31 21:10:27', '2015-10-31 21:10:27', '', 0, 'http://localhost/quotesondev/?p=91', 0, 'post', '', 0),
(93, 1, '2015-10-31 21:11:54', '2015-10-31 21:11:54', '<!-- wp:paragraph -->\n<p>Programming is not a zero-sum game. Teaching something to a fellow programmer doesn\'t take it away from you. I\'m happy to share what I can, because I\'m in it for the love of programming.</p>\n<!-- /wp:paragraph -->', 'John Carmack', '', 'publish', 'open', 'open', '', 'john-carmack', '', '', '2015-10-31 21:11:54', '2015-10-31 21:11:54', '', 0, 'http://localhost/quotesondev/?p=93', 0, 'post', '', 0),
(95, 1, '2015-10-31 21:13:05', '2015-10-31 21:13:05', '<!-- wp:paragraph -->\n<p>You might not think that programmers are artists, but programming is an extremely creative profession. It\'s logic-based creativity.</p>\n<!-- /wp:paragraph -->', 'John Romero', '', 'publish', 'open', 'open', '', 'john-romero', '', '', '2015-10-31 21:13:05', '2015-10-31 21:13:05', '', 0, 'http://localhost/quotesondev/?p=95', 0, 'post', '', 0),
(97, 1, '2015-10-31 21:14:21', '2015-10-31 21:14:21', '<!-- wp:paragraph -->\n<p>There are two ways to write error-free programs; only the third one works.</p>\n<!-- /wp:paragraph -->', 'Alan J. Perlis', '', 'publish', 'open', 'open', '', 'alan-j-perlis-2', '', '', '2015-10-31 21:14:21', '2015-10-31 21:14:21', '', 0, 'http://localhost/quotesondev/?p=97', 0, 'post', '', 0),
(101, 1, '2015-11-01 04:35:03', '2015-11-01 04:35:03', '<!-- wp:paragraph -->\n<p>HTML is the cockroach that will survive a nuclear winter.</p>\n<!-- /wp:paragraph -->', 'Jeffery Zeldman', '', 'publish', 'open', 'open', '', 'jeffery-zeldman', '', '', '2015-11-01 04:35:03', '2015-11-01 04:35:03', '', 0, 'http://localhost/quotesondev/?p=101', 0, 'post', '', 0),
(103, 1, '2015-11-01 04:35:57', '2015-11-01 04:35:57', '<!-- wp:paragraph -->\n<p>A typical CMS is like a digestive system with no capacity to poop.</p>\n<!-- /wp:paragraph -->', 'Gerry McGovern', '', 'publish', 'open', 'open', '', 'gerry-mcgovern', '', '', '2015-11-01 04:35:57', '2015-11-01 04:35:57', '', 0, 'http://localhost/quotesondev/?p=103', 0, 'post', '', 0),
(105, 1, '2015-11-01 04:40:12', '2015-11-01 04:40:12', '<!-- wp:paragraph -->\n<p>What you make with your code is how you express yourself.</p>\n<!-- /wp:paragraph -->', 'Eric Elliott', '', 'publish', 'open', 'open', '', 'eric-elliott', '', '', '2015-11-01 04:40:12', '2015-11-01 04:40:12', '', 0, 'http://localhost/quotesondev/?p=105', 0, 'post', '', 0),
(159, 1, '2017-10-10 21:41:55', '2017-10-10 21:41:55', '<!-- wp:paragraph -->\n<p>Hardware eventually fails. Software eventually works.</p>\n<!-- /wp:paragraph -->', 'Michael Hartung', '', 'publish', 'open', 'open', '', 'michael-hartung', '', '', '2017-10-10 21:41:55', '2017-10-10 21:41:55', '', 0, 'http://localhost/quotesondev/?p=159', 0, 'post', '', 0),
(161, 1, '2017-10-10 21:44:10', '2017-10-10 21:44:10', '<!-- wp:paragraph -->\n<p>The Release Uncertainty Principle says you can accurately know what the software will do, or when you will get it, but not both.</p>\n<!-- /wp:paragraph -->', 'Steve Purcell', '', 'publish', 'open', 'open', '', 'steve-purcell', '', '', '2017-10-10 21:44:10', '2017-10-10 21:44:10', '', 0, 'http://localhost/quotesondev/?p=161', 0, 'post', '', 0),
(163, 1, '2017-10-10 21:45:46', '2017-10-10 21:45:46', '<!-- wp:paragraph -->\n<p>The barman asks what the first one wants, two race conditions walk into a bar.</p>\n<!-- /wp:paragraph -->', 'I Am Devloper', '', 'publish', 'open', 'open', '', 'i-am-devloper', '', '', '2017-10-10 21:45:46', '2017-10-10 21:45:46', '', 0, 'http://localhost/quotesondev/?p=163', 0, 'post', '', 0),
(165, 1, '2017-10-10 21:47:46', '2017-10-10 21:47:46', '<!-- wp:paragraph -->\n<p>Programmer’s motto: “We’ll cross that bridge when it’s burning underneath us.”</p>\n<!-- /wp:paragraph -->', 'Gary Bernhardt', '', 'publish', 'open', 'open', '', 'gary-bernhardt', '', '', '2017-10-10 21:47:46', '2017-10-10 21:47:46', '', 0, 'http://localhost/quotesondev/?p=165', 0, 'post', '', 0),
(169, 1, '2017-10-11 12:56:06', '2017-10-11 12:56:06', '<!-- wp:paragraph -->\n<p>Some programmers, when confronted with a problem, think “I know, I’ll use floating point arithmetic.” Now they have 1.999999999997 problems.</p>\n<!-- /wp:paragraph -->', 'Tom Scott', '', 'publish', 'open', 'open', '', 'tom-scott', '', '', '2017-10-11 12:56:06', '2017-10-11 12:56:06', '', 0, 'http://localhost/quotesondev/?p=169', 0, 'post', '', 0),
(171, 1, '2017-10-11 12:57:15', '2017-10-11 12:57:15', '<!-- wp:paragraph -->\n<p>Some people, when confronted with a problem, think “I know, I’ll use multithreading”. Nothhw tpe yawrve o oblems.</p>\n<!-- /wp:paragraph -->', 'Erik Osheim', '', 'publish', 'open', 'open', '', 'erik-osheim', '', '', '2017-10-11 12:57:15', '2017-10-11 12:57:15', '', 0, 'http://localhost/quotesondev/?p=171', 0, 'post', '', 0),
(173, 1, '2017-10-11 12:58:13', '2017-10-11 12:58:13', '<!-- wp:paragraph -->\n<p>Some people, when confronted with a problem, think “I know, I’ll use versioning.” Now they have 2.1.0 problems.</p>\n<!-- /wp:paragraph -->', 'Jason Coyle', '', 'publish', 'open', 'open', '', 'jason-coyle', '', '', '2017-10-11 12:58:13', '2017-10-11 12:58:13', '', 0, 'http://localhost/quotesondev/?p=173', 0, 'post', '', 0),
(175, 1, '2017-10-11 12:58:58', '2017-10-11 12:58:58', '<!-- wp:paragraph -->\n<p>Some people, when faced with a problem, think, “I know, I’ll use binary.” Now they have 10 problems.</p>\n<!-- /wp:paragraph -->', 'Ned Batchelder', '', 'publish', 'open', 'open', '', 'ned-batchelder', '', '', '2017-10-11 12:58:58', '2017-10-11 12:58:58', '', 0, 'http://localhost/quotesondev/?p=175', 0, 'post', '', 0),
(177, 1, '2017-10-11 13:06:37', '2017-10-11 13:06:37', '<!-- wp:paragraph -->\n<p>Debugging is like being the detective in a crime movie where you are also the murderer.</p>\n<!-- /wp:paragraph -->', 'Filipe Fortes', '', 'publish', 'open', 'open', '', 'filipe-fortes', '', '', '2017-10-11 13:06:37', '2017-10-11 13:06:37', '', 0, 'http://localhost/quotesondev/?p=177', 0, 'post', '', 0),
(179, 1, '2017-10-11 13:26:04', '2017-10-11 13:26:04', '<!-- wp:paragraph -->\n<p>Unix will give you enough rope to shoot yourself in the foot. If you didn’t think rope would do that, you should have read the man page.</p>\n<!-- /wp:paragraph -->', 'Mike Hoye', '', 'publish', 'open', 'open', '', 'mike-hoye', '', '', '2017-10-11 13:26:04', '2017-10-11 13:26:04', '', 0, 'http://localhost/quotesondev/?p=179', 0, 'post', '', 0),
(181, 1, '2017-10-11 13:27:11', '2017-10-11 13:27:11', '<!-- wp:paragraph -->\n<p>When your hammer is C++, everything begins to look like a thumb.</p>\n<!-- /wp:paragraph -->', 'Steve Haflich', '', 'publish', 'open', 'open', '', 'steve-haflich', '', '', '2017-10-11 13:27:11', '2017-10-11 13:27:11', '', 0, 'http://localhost/quotesondev/?p=181', 0, 'post', '', 0),
(204, 1, '2017-10-11 13:45:57', '2017-10-11 13:45:57', '<!-- wp:paragraph -->\n<p>Do; or do not. There is no //TODO</p>\n<!-- /wp:paragraph -->', 'James Shore', '', 'publish', 'open', 'open', '', 'james-shore', '', '', '2019-11-22 18:54:30', '2019-11-22 23:54:30', '', 0, 'http://localhost/quotesondev/?p=204', 0, 'post', '', 0),
(207, 1, '2019-11-19 14:47:21', '2019-11-19 19:47:21', '', 'Submit a Quote!', '', 'publish', 'closed', 'closed', '', 'submit', '', '', '2019-11-21 16:14:13', '2019-11-21 21:14:13', '', 0, 'http://localhost/student/?page_id=207', 0, 'page', '', 0),
(211, 1, '2019-11-19 14:49:35', '2019-11-19 19:49:35', '', 'Archives', '', 'publish', 'closed', 'closed', '', 'archives', '', '', '2019-11-21 16:11:50', '2019-11-21 21:11:50', '', 0, 'http://localhost/student/?page_id=211', 0, 'page', '', 0),
(215, 1, '2019-11-19 14:51:03', '2019-11-19 19:51:03', '<!-- wp:paragraph -->\n<p>Quotes on Dev is a project site for the RED Academy Web Developer  Professional program. It’s used to experiment with Ajax, WP API, jQuery,  and other cool things. <img class="wp-image-235" style="width: 20px;" src="http://localhost/student/wp-content/uploads/2019/11/1f642.svg" alt="smile-svg"></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>This site&nbsp;is heavily inspired by Chris Coyier’s <a href="http://quotesondesign.com/" target="_blank" rel="noreferrer noopener">Quotes on Design</a>.</p>\n<!-- /wp:paragraph -->', 'About', '', 'publish', 'closed', 'closed', '', 'about-us', '', '', '2019-11-21 16:05:44', '2019-11-21 21:05:44', '', 0, 'http://localhost/student/?page_id=215', 0, 'page', '', 0),
(217, 1, '2019-11-19 14:53:18', '2019-11-19 19:53:18', '', 'Home', '', 'trash', 'closed', 'closed', '', 'home__trashed', '', '', '2019-11-21 16:47:53', '2019-11-21 21:47:53', '', 0, 'http://localhost/student/?page_id=217', 0, 'page', '', 0),
(225, 1, '2019-11-20 16:36:27', '2019-11-20 21:36:27', '', 'qod-logo', '', 'inherit', 'open', 'closed', '', 'qod-logo', '', '', '2019-11-21 16:05:44', '2019-11-21 21:05:44', '', 215, 'http://localhost/student/wp-content/uploads/2019/11/qod-logo.svg', 0, 'attachment', 'image/svg+xml', 0),
(226, 1, '2019-11-20 16:39:02', '2019-11-20 21:39:02', 'a:7:{s:8:"location";a:2:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"page";}}i:1;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"post";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'QoD-LOGO', 'qod-logo', 'publish', 'closed', 'closed', '', 'group_5dd5b1e996486', '', '', '2019-11-22 18:53:48', '2019-11-22 23:53:48', '', 0, 'http://localhost/student/?post_type=acf-field-group&#038;p=226', 0, 'acf-field-group', '', 0),
(227, 1, '2019-11-20 16:39:02', '2019-11-20 21:39:02', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:55:"any image to be uploaded will be the site\'s header logo";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'qod_logo', 'qod_logo', 'publish', 'closed', 'closed', '', 'field_5dd5b1f1a1a60', '', '', '2019-11-21 16:10:26', '2019-11-21 21:10:26', '', 226, 'http://localhost/student/?post_type=acf-field&#038;p=227', 0, 'acf-field', '', 0),
(228, 1, '2019-11-21 15:43:42', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-11-21 15:43:42', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=228', 1, 'nav_menu_item', '', 0),
(229, 1, '2019-11-21 15:45:28', '2019-11-21 20:45:28', '', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2019-11-21 15:45:40', '2019-11-21 20:45:40', '', 0, 'http://localhost/student/?p=229', 1, 'nav_menu_item', '', 0),
(230, 1, '2019-11-21 15:45:28', '2019-11-21 20:45:28', ' ', '', '', 'publish', 'closed', 'closed', '', '230', '', '', '2019-11-21 15:45:40', '2019-11-21 20:45:40', '', 0, 'http://localhost/student/?p=230', 2, 'nav_menu_item', '', 0),
(231, 1, '2019-11-21 15:43:42', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-11-21 15:43:42', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=231', 1, 'nav_menu_item', '', 0),
(232, 1, '2019-11-21 15:45:28', '2019-11-21 20:45:28', ' ', '', '', 'publish', 'closed', 'closed', '', '232', '', '', '2019-11-21 15:45:40', '2019-11-21 20:45:40', '', 0, 'http://localhost/student/?p=232', 3, 'nav_menu_item', '', 0),
(233, 1, '2019-11-21 15:45:28', '2019-11-21 20:45:28', '', 'RedAcademy', '', 'publish', 'closed', 'closed', '', 'redacademy', '', '', '2019-11-21 15:45:40', '2019-11-21 20:45:40', '', 0, 'http://localhost/student/?p=233', 4, 'nav_menu_item', '', 0),
(235, 1, '2019-11-21 15:52:20', '2019-11-21 20:52:20', '', 'smile-svg', '', 'inherit', 'open', 'closed', '', '1f642', '', '', '2019-11-21 15:52:30', '2019-11-21 20:52:30', '', 215, 'http://localhost/student/wp-content/uploads/2019/11/1f642.svg', 0, 'attachment', 'image/svg+xml', 0),
(236, 1, '2019-11-21 16:01:32', '2019-11-21 21:01:32', '<!-- wp:paragraph -->\n<p>Quotes on Dev is a project site for the RED Academy Web Developer  Professional program. It’s used to experiment with Ajax, WP API, jQuery,  and other cool things. <img class="wp-image-235" style="width: 20px;" src="http://localhost/student/wp-content/uploads/2019/11/1f642.svg" alt="smile-svg"></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>This site&nbsp;is heavily inspired by Chris Coyier’s <a href="http://quotesondesign.com/" target="_blank" rel="noreferrer noopener">Quotes on Design</a>.</p>\n<!-- /wp:paragraph -->', 'About', '', 'inherit', 'closed', 'closed', '', '215-revision-v1', '', '', '2019-11-21 16:01:32', '2019-11-21 21:01:32', '', 215, 'http://localhost/student/215-revision-v1/', 0, 'revision', '', 0),
(237, 1, '2019-11-21 16:05:44', '2019-11-21 21:05:44', '<!-- wp:paragraph -->\n<p>Quotes on Dev is a project site for the RED Academy Web Developer  Professional program. It’s used to experiment with Ajax, WP API, jQuery,  and other cool things. <img class="wp-image-235" style="width: 20px;" src="http://localhost/student/wp-content/uploads/2019/11/1f642.svg" alt="smile-svg"></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>This site&nbsp;is heavily inspired by Chris Coyier’s <a href="http://quotesondesign.com/" target="_blank" rel="noreferrer noopener">Quotes on Design</a>.</p>\n<!-- /wp:paragraph -->', 'About', '', 'inherit', 'closed', 'closed', '', '215-revision-v1', '', '', '2019-11-21 16:05:44', '2019-11-21 21:05:44', '', 215, 'http://localhost/student/215-revision-v1/', 0, 'revision', '', 0),
(238, 1, '2019-11-21 16:11:48', '2019-11-21 21:11:48', '', 'Archives', '', 'inherit', 'closed', 'closed', '', '211-revision-v1', '', '', '2019-11-21 16:11:48', '2019-11-21 21:11:48', '', 211, 'http://localhost/student/211-revision-v1/', 0, 'revision', '', 0),
(239, 1, '2019-11-21 16:11:50', '2019-11-21 21:11:50', '', 'Archives', '', 'inherit', 'closed', 'closed', '', '211-revision-v1', '', '', '2019-11-21 16:11:50', '2019-11-21 21:11:50', '', 211, 'http://localhost/student/211-revision-v1/', 0, 'revision', '', 0),
(240, 1, '2019-11-21 16:14:12', '2019-11-21 21:14:12', '', 'Submit a Quote!', '', 'inherit', 'closed', 'closed', '', '207-revision-v1', '', '', '2019-11-21 16:14:12', '2019-11-21 21:14:12', '', 207, 'http://localhost/student/207-revision-v1/', 0, 'revision', '', 0),
(241, 1, '2019-11-21 16:14:13', '2019-11-21 21:14:13', '', 'Submit a Quote!', '', 'inherit', 'closed', 'closed', '', '207-revision-v1', '', '', '2019-11-21 16:14:13', '2019-11-21 21:14:13', '', 207, 'http://localhost/student/207-revision-v1/', 0, 'revision', '', 0),
(242, 1, '2019-11-21 16:14:27', '2019-11-21 21:14:27', '', 'Submit a Quote!', '', 'inherit', 'closed', 'closed', '', '207-autosave-v1', '', '', '2019-11-21 16:14:27', '2019-11-21 21:14:27', '', 207, 'http://localhost/student/207-autosave-v1/', 0, 'revision', '', 0),
(243, 1, '2019-11-21 16:47:53', '2019-11-21 21:47:53', '', 'Home', '', 'inherit', 'closed', 'closed', '', '217-revision-v1', '', '', '2019-11-21 16:47:53', '2019-11-21 21:47:53', '', 217, 'http://localhost/student/217-revision-v1/', 0, 'revision', '', 0),
(244, 1, '2019-11-21 17:12:24', '2019-11-21 22:12:24', '', 'home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2019-11-21 17:13:53', '2019-11-21 22:13:53', '', 0, 'http://localhost/student/?page_id=244', 0, 'page', '', 0),
(245, 1, '2019-11-21 17:12:24', '2019-11-21 22:12:24', '', 'home', '', 'inherit', 'closed', 'closed', '', '244-revision-v1', '', '', '2019-11-21 17:12:24', '2019-11-21 22:12:24', '', 244, 'http://localhost/student/244-revision-v1/', 0, 'revision', '', 0),
(246, 1, '2019-11-21 17:12:25', '2019-11-21 22:12:25', '', 'home', '', 'inherit', 'closed', 'closed', '', '244-revision-v1', '', '', '2019-11-21 17:12:25', '2019-11-21 22:12:25', '', 244, 'http://localhost/student/244-revision-v1/', 0, 'revision', '', 0),
(247, 1, '2019-11-21 22:56:46', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2019-11-21 22:56:46', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=247', 0, 'post', '', 0),
(249, 1, '2019-11-22 18:54:28', '2019-11-22 23:54:28', '<!-- wp:paragraph -->\n<p>Do; or do not. There is no //TODO</p>\n<!-- /wp:paragraph -->', 'James Shore', '', 'inherit', 'closed', 'closed', '', '204-revision-v1', '', '', '2019-11-22 18:54:28', '2019-11-22 23:54:28', '', 204, 'http://localhost/student/204-revision-v1/', 0, 'revision', '', 0),
(250, 1, '2019-11-22 18:54:30', '2019-11-22 23:54:30', '<!-- wp:paragraph -->\n<p>Do; or do not. There is no //TODO</p>\n<!-- /wp:paragraph -->', 'James Shore', '', 'inherit', 'closed', 'closed', '', '204-revision-v1', '', '', '2019-11-22 18:54:30', '2019-11-22 23:54:30', '', 204, 'http://localhost/student/204-revision-v1/', 0, 'revision', '', 0),
(251, 1, '2019-11-25 16:18:43', '2019-11-25 21:18:43', 'test content', 'test-title', '', 'trash', 'closed', 'open', '', 'test-title__trashed', '', '', '2019-11-25 16:24:33', '2019-11-25 21:24:33', '', 0, 'http://localhost/student/?p=251', 0, 'post', '', 0),
(252, 1, '2019-11-25 16:18:43', '2019-11-25 21:18:43', 'test content', 'test-title', '', 'inherit', 'closed', 'closed', '', '251-revision-v1', '', '', '2019-11-25 16:18:43', '2019-11-25 21:18:43', '', 251, 'http://localhost/student/251-revision-v1/', 0, 'revision', '', 0),
(253, 1, '2019-11-25 17:27:23', '2019-11-25 22:27:23', 'gtrdgrd', 'eae`trert`', '', 'trash', 'closed', 'open', '', '__trashed-2', '', '', '2019-11-25 17:27:23', '2019-11-25 22:27:23', '', 0, 'http://localhost/student/?p=253', 0, 'post', '', 0),
(254, 1, '2019-11-25 17:27:19', '2019-11-25 22:27:19', 'gtrdgrd', 'eae`trert`', '', 'trash', 'closed', 'open', '', '__trashed', '', '', '2019-11-25 17:27:19', '2019-11-25 22:27:19', '', 0, 'http://localhost/student/?p=254', 0, 'post', '', 0),
(255, 1, '2019-11-25 17:27:19', '2019-11-25 22:27:19', 'gtrdgrd', 'eae`trert`', '', 'inherit', 'closed', 'closed', '', '254-revision-v1', '', '', '2019-11-25 17:27:19', '2019-11-25 22:27:19', '', 254, 'http://localhost/student/254-revision-v1/', 0, 'revision', '', 0),
(256, 1, '2019-11-25 17:27:23', '2019-11-25 22:27:23', 'gtrdgrd', 'eae`trert`', '', 'inherit', 'closed', 'closed', '', '253-revision-v1', '', '', '2019-11-25 17:27:23', '2019-11-25 22:27:23', '', 253, 'http://localhost/student/253-revision-v1/', 0, 'revision', '', 0),
(257, 1, '2019-11-25 17:29:47', '2019-11-25 22:29:47', 'adbul', 'abdul', '', 'trash', 'closed', 'open', '', '__trashed-3', '', '', '2019-11-25 17:29:47', '2019-11-25 22:29:47', '', 0, 'http://localhost/student/?p=257', 0, 'post', '', 0),
(258, 1, '2019-11-25 17:29:47', '2019-11-25 22:29:47', 'adbul', 'abdul', '', 'inherit', 'closed', 'closed', '', '257-revision-v1', '', '', '2019-11-25 17:29:47', '2019-11-25 22:29:47', '', 257, 'http://localhost/student/257-revision-v1/', 0, 'revision', '', 0),
(259, 1, '2019-11-26 00:56:46', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2019-11-26 00:56:46', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?post_type=acf-field-group&p=259', 0, 'acf-field-group', '', 0) ;

#
# End of data contents of table `qod_posts`
# --------------------------------------------------------



#
# Delete any existing table `qod_term_relationships`
#

DROP TABLE IF EXISTS `qod_term_relationships`;


#
# Table structure of table `qod_term_relationships`
#

CREATE TABLE `qod_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `qod_term_relationships`
#
INSERT INTO `qod_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(19, 2, 0),
(21, 3, 0),
(21, 4, 0),
(23, 3, 0),
(25, 5, 0),
(25, 6, 0),
(27, 5, 0),
(27, 7, 0),
(29, 3, 0),
(29, 8, 0),
(31, 3, 0),
(33, 1, 0),
(33, 9, 0),
(35, 3, 0),
(37, 1, 0),
(37, 4, 0),
(39, 3, 0),
(39, 4, 0),
(41, 3, 0),
(43, 1, 0),
(43, 10, 0),
(45, 11, 0),
(47, 6, 0),
(47, 12, 0),
(47, 13, 0),
(47, 14, 0),
(49, 6, 0),
(49, 12, 0),
(49, 13, 0),
(49, 14, 0),
(51, 15, 0),
(51, 16, 0),
(51, 17, 0),
(51, 18, 0),
(53, 5, 0),
(53, 19, 0),
(55, 2, 0),
(55, 3, 0),
(57, 2, 0),
(57, 3, 0),
(59, 20, 0),
(61, 5, 0),
(61, 11, 0),
(63, 3, 0),
(65, 20, 0),
(65, 21, 0),
(67, 2, 0),
(67, 22, 0),
(69, 1, 0),
(69, 23, 0),
(71, 20, 0),
(73, 2, 0),
(73, 5, 0),
(73, 21, 0),
(75, 11, 0),
(77, 24, 0),
(77, 25, 0),
(79, 20, 0),
(79, 21, 0),
(79, 26, 0),
(81, 1, 0),
(81, 4, 0),
(81, 21, 0),
(81, 27, 0),
(83, 5, 0),
(83, 15, 0),
(85, 5, 0),
(87, 3, 0),
(87, 28, 0),
(89, 15, 0),
(89, 21, 0),
(89, 29, 0),
(89, 30, 0),
(91, 1, 0),
(91, 4, 0),
(91, 21, 0),
(93, 6, 0),
(93, 13, 0),
(93, 14, 0),
(95, 2, 0),
(95, 12, 0),
(97, 11, 0),
(101, 15, 0),
(101, 31, 0),
(103, 1, 0),
(103, 32, 0),
(105, 2, 0),
(105, 12, 0),
(159, 1, 0),
(159, 27, 0),
(159, 33, 0),
(161, 5, 0),
(161, 33, 0),
(163, 5, 0),
(165, 5, 0),
(169, 24, 0),
(169, 34, 0),
(171, 24, 0),
(171, 35, 0),
(173, 24, 0) ;
INSERT INTO `qod_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(173, 36, 0),
(175, 24, 0),
(175, 37, 0),
(177, 11, 0),
(179, 5, 0),
(179, 38, 0),
(179, 39, 0),
(181, 15, 0),
(181, 40, 0),
(204, 5, 0),
(204, 28, 0),
(229, 41, 0),
(230, 41, 0),
(232, 41, 0),
(233, 41, 0),
(251, 1, 0),
(253, 1, 0),
(254, 1, 0),
(257, 1, 0) ;

#
# End of data contents of table `qod_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `qod_term_taxonomy`
#

DROP TABLE IF EXISTS `qod_term_taxonomy`;


#
# Table structure of table `qod_term_taxonomy`
#

CREATE TABLE `qod_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `qod_term_taxonomy`
#
INSERT INTO `qod_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 8),
(2, 2, 'category', '', 0, 7),
(3, 3, 'category', '', 0, 11),
(4, 4, 'post_tag', '', 0, 5),
(5, 5, 'category', '', 0, 12),
(6, 6, 'category', '', 0, 4),
(7, 7, 'post_tag', '', 0, 1),
(8, 8, 'post_tag', '', 0, 1),
(9, 9, 'post_tag', '', 0, 1),
(10, 10, 'post_tag', '', 0, 1),
(11, 11, 'category', '', 0, 5),
(12, 12, 'post_tag', '', 0, 4),
(13, 13, 'post_tag', '', 0, 3),
(14, 14, 'post_tag', '', 0, 3),
(15, 15, 'category', '', 0, 5),
(16, 16, 'post_tag', '', 0, 1),
(17, 17, 'post_tag', '', 0, 1),
(18, 18, 'post_tag', '', 0, 1),
(19, 19, 'post_tag', '', 0, 1),
(20, 20, 'category', '', 0, 4),
(21, 21, 'post_tag', '', 0, 6),
(22, 22, 'post_tag', '', 0, 1),
(23, 23, 'post_tag', '', 0, 1),
(24, 24, 'category', '', 0, 5),
(25, 25, 'post_tag', '', 0, 1),
(26, 26, 'post_tag', '', 0, 1),
(27, 27, 'post_tag', '', 0, 2),
(28, 28, 'post_tag', '', 0, 2),
(29, 29, 'post_tag', '', 0, 1),
(30, 30, 'post_tag', '', 0, 1),
(31, 31, 'post_tag', '', 0, 1),
(32, 32, 'post_tag', '', 0, 1),
(33, 33, 'post_tag', '', 0, 2),
(34, 34, 'post_tag', '', 0, 1),
(35, 35, 'post_tag', '', 0, 1),
(36, 36, 'post_tag', '', 0, 1),
(37, 37, 'post_tag', '', 0, 1),
(38, 38, 'post_tag', '', 0, 1),
(39, 39, 'post_tag', '', 0, 1),
(40, 40, 'post_tag', '', 0, 1),
(41, 41, 'nav_menu', '', 0, 4) ;

#
# End of data contents of table `qod_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `qod_termmeta`
#

DROP TABLE IF EXISTS `qod_termmeta`;


#
# Table structure of table `qod_termmeta`
#

CREATE TABLE `qod_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `qod_termmeta`
#

#
# End of data contents of table `qod_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `qod_terms`
#

DROP TABLE IF EXISTS `qod_terms`;


#
# Table structure of table `qod_terms`
#

CREATE TABLE `qod_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `qod_terms`
#
INSERT INTO `qod_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Programming', 'programming', 0),
(3, 'Best Practices', 'best-practices', 0),
(4, 'computers', 'computers', 0),
(5, 'Humour', 'humour', 0),
(6, 'Learning to Code', 'learning-to-code', 0),
(7, 'perl', 'perl', 0),
(8, 'specifications', 'specifications', 0),
(9, 'critique', 'critique', 0),
(10, 'history', 'history', 0),
(11, 'Debugging', 'debugging', 0),
(12, 'creativity', 'creativity', 0),
(13, 'education', 'education', 0),
(14, 'teaching', 'teaching', 0),
(15, 'Languages', 'languages', 0),
(16, 'lisp', 'lisp', 0),
(17, 'mvc', 'mvc', 0),
(18, 'smalltalk', 'smalltalk', 0),
(19, 'plain text', 'plain-text', 0),
(20, 'Productivity', 'productivity', 0),
(21, 'analogies', 'analogies', 0),
(22, 'work', 'work', 0),
(23, 'computer science', 'computer-science', 0),
(24, 'Now They Have Two Problems', 'two-problems', 0),
(25, 'regular expressions', 'regular-expressions', 0),
(26, 'project management', 'project-management', 0),
(27, 'hardware', 'hardware', 0),
(28, 'commenting', 'commenting', 0),
(29, 'java', 'java', 0),
(30, 'javascript', 'javascript', 0),
(31, 'html', 'html', 0),
(32, 'cms', 'cms', 0),
(33, 'software', 'software', 0),
(34, 'floating point', 'floating-point', 0),
(35, 'threading', 'threading', 0),
(36, 'semver', 'semver', 0),
(37, 'binary', 'binary', 0),
(38, 'operating systems', 'operating-systems', 0),
(39, 'unix', 'unix', 0),
(40, 'c++', 'c', 0),
(41, 'Site_Menu', 'site_menu', 0) ;

#
# End of data contents of table `qod_terms`
# --------------------------------------------------------



#
# Delete any existing table `qod_usermeta`
#

DROP TABLE IF EXISTS `qod_usermeta`;


#
# Table structure of table `qod_usermeta`
#

CREATE TABLE `qod_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `qod_usermeta`
#
INSERT INTO `qod_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'soservin07'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'qod_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'qod_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '0'),
(16, 1, 'session_tokens', 'a:6:{s:64:"bf5472c5102062bf2caaf1cdc417f98366616bbcbe43e4382bcfd709b63cdb86";a:4:{s:10:"expiration";i:1574889486;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:78:"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:71.0) Gecko/20100101 Firefox/71.0";s:5:"login";i:1574716686;}s:64:"a21ab7f4dd02e28cfc18fafe8c121e7a6a8ac3d877ea78bbe9aa82fc3890c69a";a:4:{s:10:"expiration";i:1574889486;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36";s:5:"login";i:1574716686;}s:64:"128b7becc5acd2f53136dea42315285f4ac29ba98dc270a2ba1bc62824150d39";a:4:{s:10:"expiration";i:1574889486;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36";s:5:"login";i:1574716686;}s:64:"a59451fe05af711fa5f5269fa3434b1d5dcefbc39030a7b81b46b0ad5fbc54e0";a:4:{s:10:"expiration";i:1574916600;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36";s:5:"login";i:1574743800;}s:64:"67a9c10ea2f5631076bfd9b10d44483f3a7020abbd3ef5f8be7514ca0d3acc09";a:4:{s:10:"expiration";i:1574920509;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36";s:5:"login";i:1574747709;}s:64:"dbafa62f221ff3291efaac4844f2fb8ba3329cc06417511b7efb0311869ad2c9";a:4:{s:10:"expiration";i:1574923375;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36";s:5:"login";i:1574750575;}}'),
(17, 1, 'qod_dashboard_quick_press_last_post_id', '247'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:9:"127.0.0.0";}'),
(19, 1, 'wpcf7_hide_welcome_panel_on', 'a:1:{i:0;s:3:"5.1";}'),
(20, 1, 'qod_user-settings', 'libraryContent=browse'),
(21, 1, 'qod_user-settings-time', '1574295732'),
(22, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(23, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(24, 1, 'closedpostboxes_page', 'a:0:{}'),
(25, 1, 'metaboxhidden_page', 'a:0:{}'),
(26, 1, 'meta-box-order_page', 'a:4:{s:6:"normal";s:23:"acf-group_5dd5b1e996486";s:15:"acf_after_title";s:0:"";s:4:"side";s:0:"";s:8:"advanced";s:0:"";}'),
(27, 1, 'meta-box-order_acf-field-group', 'a:3:{s:4:"side";s:9:"submitdiv";s:6:"normal";s:80:"acf-field-group-fields,acf-field-group-locations,acf-field-group-options,slugdiv";s:8:"advanced";s:0:"";}'),
(28, 1, 'screen_layout_acf-field-group', '2'),
(29, 1, 'closedpostboxes_acf-field-group', 'a:0:{}'),
(30, 1, 'metaboxhidden_acf-field-group', 'a:1:{i:0;s:7:"slugdiv";}'),
(31, 2, 'nickname', 'instructor'),
(32, 2, 'first_name', 'Jim'),
(33, 2, 'last_name', 'Bennett'),
(34, 2, 'description', ''),
(35, 2, 'rich_editing', 'true'),
(36, 2, 'syntax_highlighting', 'true'),
(37, 2, 'comment_shortcuts', 'false'),
(38, 2, 'admin_color', 'fresh'),
(39, 2, 'use_ssl', '0'),
(40, 2, 'show_admin_bar_front', 'true'),
(41, 2, 'locale', ''),
(42, 2, 'qod_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(43, 2, 'qod_user_level', '10'),
(44, 2, 'dismissed_wp_pointers', '') ;

#
# End of data contents of table `qod_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `qod_users`
#

DROP TABLE IF EXISTS `qod_users`;


#
# Table structure of table `qod_users`
#

CREATE TABLE `qod_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `qod_users`
#
INSERT INTO `qod_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'soservin07', '$P$BY8AF7Fm7O21GBahD3A5FaoI8PMgIL0', 'soservin07', 'soservin@ymail.com', '', '2019-11-19 19:24:13', '', 0, 'soservin07'),
(2, 'instructor', '$P$BRrRTp4um3ygrvmVwqCgv7oIeLixIz0', 'instructor', 'jim.bennett@redacademy.com', '', '2019-11-26 06:44:59', '1574750701:$P$BJHGUG.Sq4PPU8/sGNVJetLM6ROGip0', 0, 'Jim Bennett') ;

#
# End of data contents of table `qod_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

